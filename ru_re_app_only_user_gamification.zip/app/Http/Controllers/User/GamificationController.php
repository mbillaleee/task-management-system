<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Badge;
use App\Models\Challenge;
use App\Models\DailyReward;
use App\Models\UserBadge;
use App\Models\UserChallenge;
use App\Models\UserGamification;
use Illuminate\Http\Request;

class GamificationController extends Controller
{
    public function index()
    {
        $gamification = UserGamification::firstOrCreate(
            ['user_id' => auth()->id()],
            [
                'xp' => 0,
                'level' => 1,
                'streak_days' => 0,
                'last_activity_date' => null,
                'daily_reward_claimed' => 0,
            ]
        );

        $badges = Badge::where('is_active', true)->latest()->get();

        $userBadges = UserBadge::with('badge')
            ->where('user_id', auth()->id())
            ->latest()
            ->get();

        $challenges = Challenge::where('is_active', true)->latest()->get();

        $userChallenges = UserChallenge::with('challenge')
            ->where('user_id', auth()->id())
            ->latest()
            ->get();

        $dailyRewards = DailyReward::orderBy('day_number')->get();

        $nextLevelXp = $gamification->level * 100;
        $levelProgress = $nextLevelXp > 0 ? min(round(($gamification->xp / $nextLevelXp) * 100), 100) : 0;

        return view('user.gamification.index', compact(
            'gamification',
            'badges',
            'userBadges',
            'challenges',
            'userChallenges',
            'dailyRewards',
            'nextLevelXp',
            'levelProgress'
        ));
    }

    public function addXp(Request $request)
    {
        $request->validate([
            'xp' => 'required|integer|min:1',
        ]);

        $gamification = UserGamification::firstOrCreate(['user_id' => auth()->id()]);

        $gamification->xp += $request->xp;
        $gamification->level = floor($gamification->xp / 100) + 1;
        $gamification->last_activity_date = today();
        $gamification->save();

        $this->unlockBadges($gamification);

        return back()->with('success', 'XP added successfully.');
    }

    public function claimDailyReward()
    {
        $gamification = UserGamification::firstOrCreate(['user_id' => auth()->id()]);

        if ($gamification->last_activity_date && $gamification->last_activity_date->isToday()) {
            return back()->with('error', 'Daily reward already claimed today.');
        }

        if ($gamification->last_activity_date && $gamification->last_activity_date->isYesterday()) {
            $gamification->streak_days += 1;
        } else {
            $gamification->streak_days = 1;
        }

        $reward = DailyReward::where('day_number', min($gamification->streak_days, 7))->first();

        $xpReward = $reward?->xp_reward ?? 10;

        $gamification->xp += $xpReward;
        $gamification->level = floor($gamification->xp / 100) + 1;
        $gamification->last_activity_date = today();
        $gamification->daily_reward_claimed += 1;
        $gamification->save();

        $this->unlockBadges($gamification);

        return back()->with('success', 'Daily reward claimed. XP earned: ' . $xpReward);
    }

    private function unlockBadges(UserGamification $gamification): void
    {
        $badges = Badge::where('is_active', true)
            ->where('xp_required', '<=', $gamification->xp)
            ->get();

        foreach ($badges as $badge) {
            UserBadge::firstOrCreate([
                'user_id' => auth()->id(),
                'badge_id' => $badge->id,
            ], [
                'unlocked_at' => now(),
            ]);
        }
    }
}