<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Challenge;
use App\Models\UserChallenge;
use App\Models\UserGamification;
use Illuminate\Http\Request;

class ChallengeController extends Controller
{
    public function index()
    {
        $challenges = Challenge::latest()->paginate(12);

        return view('user.gamification.challenges', compact('challenges'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'required|in:daily,weekly,monthly',
            'target_value' => 'required|integer|min:1',
            'xp_reward' => 'required|integer|min:1',
            'reward_title' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        Challenge::create([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'target_value' => $request->target_value,
            'xp_reward' => $request->xp_reward,
            'reward_title' => $request->reward_title,
            'is_active' => $request->boolean('is_active'),
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ]);

        return back()->with('success', 'Challenge created successfully.');
    }

    public function update(Request $request, Challenge $challenge)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'required|in:daily,weekly,monthly',
            'target_value' => 'required|integer|min:1',
            'xp_reward' => 'required|integer|min:1',
            'reward_title' => 'nullable|string|max:255',
            'is_active' => 'nullable|boolean',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
        ]);

        $challenge->update([
            'title' => $request->title,
            'description' => $request->description,
            'type' => $request->type,
            'target_value' => $request->target_value,
            'xp_reward' => $request->xp_reward,
            'reward_title' => $request->reward_title,
            'is_active' => $request->boolean('is_active'),
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ]);

        return back()->with('success', 'Challenge updated successfully.');
    }

    public function destroy(Challenge $challenge)
    {
        $challenge->delete();

        return back()->with('success', 'Challenge deleted successfully.');
    }

    public function join(Challenge $challenge)
    {
        UserChallenge::firstOrCreate([
            'user_id' => auth()->id(),
            'challenge_id' => $challenge->id,
        ]);

        return back()->with('success', 'Challenge joined successfully.');
    }

    public function progress(Request $request, UserChallenge $userChallenge)
    {
        abort_if($userChallenge->user_id !== auth()->id(), 403);

        $request->validate([
            'progress' => 'required|integer|min:1',
        ]);

        $userChallenge->progress += $request->progress;

        if ($userChallenge->progress >= $userChallenge->challenge->target_value && !$userChallenge->is_completed) {
            $userChallenge->is_completed = true;
            $userChallenge->completed_at = now();

            $gamification = UserGamification::firstOrCreate(['user_id' => auth()->id()]);
            $gamification->xp += $userChallenge->challenge->xp_reward;
            $gamification->level = floor($gamification->xp / 100) + 1;
            $gamification->save();
        }

        $userChallenge->save();

        return back()->with('success', 'Challenge progress updated.');
    }
}