<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Badge;
use Illuminate\Http\Request;

class BadgeController extends Controller
{
    public function index()
    {
        $badges = Badge::latest()->paginate(12);

        return view('user.gamification.badges', compact('badges'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'icon' => 'nullable|string|max:50',
            'color' => 'nullable|string|max:20',
            'xp_required' => 'required|integer|min:0',
            'is_active' => 'nullable|boolean',
        ]);

        Badge::create([
            'name' => $request->name,
            'description' => $request->description,
            'icon' => $request->icon,
            'color' => $request->color ?? '#f97316',
            'xp_required' => $request->xp_required,
            'is_active' => $request->boolean('is_active'),
        ]);

        return back()->with('success', 'Badge created successfully.');
    }

    public function update(Request $request, Badge $badge)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'icon' => 'nullable|string|max:50',
            'color' => 'nullable|string|max:20',
            'xp_required' => 'required|integer|min:0',
            'is_active' => 'nullable|boolean',
        ]);

        $badge->update([
            'name' => $request->name,
            'description' => $request->description,
            'icon' => $request->icon,
            'color' => $request->color ?? '#f97316',
            'xp_required' => $request->xp_required,
            'is_active' => $request->boolean('is_active'),
        ]);

        return back()->with('success', 'Badge updated successfully.');
    }

    public function destroy(Badge $badge)
    {
        $badge->delete();

        return back()->with('success', 'Badge deleted successfully.');
    }
}
