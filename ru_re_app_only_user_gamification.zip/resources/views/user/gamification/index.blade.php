@extends('user.layouts.master')

@section('user')
    <section class="space-y-6">

        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div>
                <h2 class="text-[20px] font-extrabold tracking-[-0.3px] dark:text-white text-gray-900">
                    Gamification Workspace
                </h2>
                <p class="text-[14px] dark:text-gray-500 text-gray-400 mt-0.5">
                    XP, levels, badges, rewards, progression and challenges.
                </p>
            </div>

            <div class="flex items-center gap-2.5">
                <a href="{{ route('user.badges.index') }}"
                    class="px-4 py-2 rounded-[10px] text-[14px] font-bold dark:bg-white/[0.07] bg-white dark:text-gray-300 text-gray-700 border dark:border-white/[0.08] border-black/[0.08]">
                    Badges
                </a>

                <a href="{{ route('user.challenges.index') }}"
                    class="px-4 py-2 rounded-[10px] text-[14px] font-bold dark:bg-white/[0.07] bg-white dark:text-gray-300 text-gray-700 border dark:border-white/[0.08] border-black/[0.08]">
                    Challenges
                </a>

                <form action="{{ route('user.gamification.claimDailyReward') }}" method="POST">
                    @csrf
                    <button
                        class="px-4 py-2 rounded-[10px] text-white text-[14px] font-bold bg-gradient-to-r from-orange-500 to-pink-500">
                        Claim Daily Reward
                    </button>
                </form>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div
                class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-5">
                <p class="text-[14px] dark:text-gray-400 text-gray-500 font-bold">Total XP</p>
                <h3 class="text-[34px] font-black dark:text-white text-gray-900 mt-2">{{ $gamification->xp }}</h3>
                <p class="text-[13px] text-orange-400 font-bold">Experience points</p>
            </div>

            <div
                class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-5">
                <p class="text-[14px] dark:text-gray-400 text-gray-500 font-bold">Level</p>
                <h3 class="text-[34px] font-black text-pink-400 mt-2">{{ $gamification->level }}</h3>
                <p class="text-[13px] text-pink-400 font-bold">Current level</p>
            </div>

            <div
                class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-5">
                <p class="text-[14px] dark:text-gray-400 text-gray-500 font-bold">Streak</p>
                <h3 class="text-[34px] font-black text-emerald-400 mt-2">{{ $gamification->streak_days }}</h3>
                <p class="text-[13px] text-emerald-400 font-bold">Daily streak days</p>
            </div>

            <div
                class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-5">
                <p class="text-[14px] dark:text-gray-400 text-gray-500 font-bold">Badges</p>
                <h3 class="text-[34px] font-black text-yellow-400 mt-2">{{ $userBadges->count() }}</h3>
                <p class="text-[13px] text-yellow-400 font-bold">Unlocked badges</p>
            </div>
        </div>

        <div
            class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-[18px]">
            <div class="flex justify-between text-[14px] mb-2">
                <span class="dark:text-gray-400 text-gray-500 font-bold">Progression System</span>
                <span class="dark:text-white text-gray-900 font-bold">{{ $levelProgress }}%</span>
            </div>

            <div class="w-full h-[10px] rounded-full dark:bg-white/[0.08] bg-gray-100 overflow-hidden">
                <div class="h-full rounded-full bg-gradient-to-r from-orange-500 to-pink-500"
                    style="width: {{ $levelProgress }}%"></div>
            </div>

            <p class="text-[13px] dark:text-gray-500 text-gray-400 mt-2">
                {{ $gamification->xp }} / {{ $nextLevelXp }} XP for next level
            </p>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <div
                class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-[18px]">
                <h3 class="text-[18px] font-extrabold dark:text-white text-gray-900 mb-4">Unlocked Badges</h3>

                <div class="space-y-3">
                    @forelse($userBadges as $userBadge)
                        <div class="flex items-center gap-3 p-3 rounded-xl dark:bg-white/[0.04] bg-gray-50">
                            <div class="w-11 h-11 rounded-xl flex items-center justify-center text-white font-black"
                                style="background: {{ $userBadge->badge->color }}">
                                {{ $userBadge->badge->icon ?? '🏆' }}
                            </div>

                            <div>
                                <h4 class="text-[14px] font-bold dark:text-white text-gray-900">
                                    {{ $userBadge->badge->name }}
                                </h4>
                                <p class="text-[12px] dark:text-gray-500 text-gray-400">
                                    Unlocked {{ $userBadge->unlocked_at?->format('d M, Y') }}
                                </p>
                            </div>
                        </div>
                    @empty
                        <p class="text-center text-gray-500 py-8">No badges unlocked yet.</p>
                    @endforelse
                </div>
            </div>

            <div
                class="hover-lift dark:bg-[#17141f] bg-white border dark:border-white/[0.07] border-black/[0.07] rounded-2xl p-[18px]">
                <h3 class="text-[18px] font-extrabold dark:text-white text-gray-900 mb-4">My Challenges</h3>

                <div class="space-y-3">
                    @forelse($userChallenges as $userChallenge)
                        @php
                            $progressPercent =
                                $userChallenge->challenge->target_value > 0
                                    ? min(
                                        round(
                                            ($userChallenge->progress / $userChallenge->challenge->target_value) * 100,
                                        ),
                                        100,
                                    )
                                    : 0;
                        @endphp

                        <div class="p-3 rounded-xl dark:bg-white/[0.04] bg-gray-50">
                            <div class="flex items-center justify-between">
                                <h4 class="text-[14px] font-bold dark:text-white text-gray-900">
                                    {{ $userChallenge->challenge->title }}
                                </h4>

                                <span class="text-[12px] font-bold text-orange-400">
                                    +{{ $userChallenge->challenge->xp_reward }} XP
                                </span>
                            </div>

                            <div class="mt-3">
                                <div class="flex justify-between text-[12px] mb-1">
                                    <span class="text-gray-400">Progress</span>
                                    <span class="dark:text-white text-gray-700">
                                        {{ $userChallenge->progress }}/{{ $userChallenge->challenge->target_value }}
                                    </span>
                                </div>

                                <div class="w-full h-[7px] rounded-full dark:bg-white/[0.08] bg-gray-100 overflow-hidden">
                                    <div class="h-full rounded-full bg-gradient-to-r from-orange-500 to-pink-500"
                                        style="width: {{ $progressPercent }}%"></div>
                                </div>
                            </div>

                            @if (!$userChallenge->is_completed)
                                <form action="{{ route('user.userChallenges.progress', $userChallenge) }}" method="POST"
                                    class="mt-3 flex gap-2">
                                    @csrf
                                    @method('PATCH')
                                    <input type="number" name="progress" value="1" min="1"
                                        class="w-full px-3 py-2 rounded-lg text-[13px] dark:bg-[#1a1625] bg-white dark:text-white border dark:border-white/[0.1]">
                                    <button
                                        class="px-3 py-2 rounded-lg text-white text-[13px] font-bold bg-gradient-to-r from-orange-500 to-pink-500">
                                        Add
                                    </button>
                                </form>
                            @else
                                <p class="mt-3 text-[13px] text-emerald-400 font-bold">Completed</p>
                            @endif
                        </div>
                    @empty
                        <p class="text-center text-gray-500 py-8">No challenges joined yet.</p>
                    @endforelse
                </div>
            </div>
        </div>

    </section>
@endsection
