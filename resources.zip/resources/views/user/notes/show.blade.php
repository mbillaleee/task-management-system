@extends('user.layouts.master')

@section('user')
<div class="space-y-5">

    <section
        class="relative overflow-hidden rounded-2xl border dark:border-orange-500/[0.18] border-orange-200/70
        dark:bg-[#100b18] bg-orange-50/70 px-6 py-6">

        <div class="absolute inset-0 opacity-40 pointer-events-none"
            style="background:
            radial-gradient(circle at 80% 35%, rgba(236,72,153,.30), transparent 35%),
            radial-gradient(circle at 25% 75%, rgba(249,115,22,.25), transparent 32%);">
        </div>

        <div class="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div>
                <div class="flex items-center gap-2 mb-3">
                    @if($note->is_pinned)
                        <span class="text-[20px]">📌</span>
                    @endif

                    @if($note->is_favorite)
                        <span class="text-[20px]">⭐</span>
                    @endif

                    <span class="px-3 py-1 rounded-lg text-[12px] font-bold
                        dark:bg-orange-500/[0.14] bg-orange-50 text-orange-500
                        border dark:border-orange-500/[0.22] border-orange-200">
                        {{ ucfirst($note->status) }}
                    </span>
                </div>

                <h1 class="text-[34px] sm:text-[42px] font-extrabold leading-[1.1] dark:text-white text-gray-900">
                    {{ $note->title }}
                </h1>

                <p class="text-[14px] dark:text-gray-500 text-gray-500 mt-3">
                    Last edited:
                    {{ $note->last_edited_at ? $note->last_edited_at->format('d M Y, h:i A') : $note->updated_at->format('d M Y, h:i A') }}
                </p>
            </div>

            <div class="flex flex-wrap items-center gap-2.5">
                <a href="{{ route('user.notes.index') }}"
                    class="px-5 py-3 rounded-xl text-[14px] font-bold
                    dark:text-white text-gray-800 border dark:border-white/[0.14] border-orange-200
                    dark:bg-white/[0.03] bg-white/70">
                    ← Back
                </a>

                <a href="{{ route('user.notes.edit', $note) }}"
                    class="px-5 py-3 rounded-xl text-white text-[14px] font-bold
                    bg-gradient-to-r from-orange-500 to-pink-500
                    shadow-[0_4px_18px_rgba(249,115,22,.35)]">
                    Edit Note
                </a>
            </div>
        </div>
    </section>

    <div class="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-5">

        <!-- Content -->
        <section
            class="rounded-2xl border dark:border-orange-500/[0.18] border-orange-200
            dark:bg-[#0f0b18] bg-orange-50/50 p-5 shadow-[0_0_35px_rgba(249,115,22,.12)]">

            <div class="rounded-2xl p-6 min-h-[420px]
                dark:bg-[#17141f] bg-white
                border dark:border-pink-500/[0.18] border-orange-100">

                <div class="prose max-w-none dark:prose-invert">
                    <div class="text-[15px] leading-[1.9] dark:text-gray-300 text-gray-700 whitespace-pre-line">
                        {{ $note->content ?: 'No content added yet.' }}
                    </div>
                </div>
            </div>
        </section>

        <!-- Sidebar -->
        <aside class="space-y-4">

            <div class="rounded-2xl p-5 dark:bg-[#17141f] bg-white border dark:border-pink-500/[0.18] border-orange-100">
                <h3 class="text-[18px] font-extrabold dark:text-white text-gray-900 mb-4">
                    Note Details
                </h3>

                <div class="space-y-3 text-[14px]">
                    <div>
                        <p class="dark:text-gray-500 text-gray-400 mb-1">Folder</p>
                        <p class="font-bold dark:text-gray-200 text-gray-800">
                            {{ $note->folder?->name ?? 'No Folder' }}
                        </p>
                    </div>

                    <div>
                        <p class="dark:text-gray-500 text-gray-400 mb-1">Category</p>
                        <p class="font-bold dark:text-gray-200 text-gray-800">
                            {{ $note->category?->name ?? 'No Category' }}
                        </p>
                    </div>

                    <div>
                        <p class="dark:text-gray-500 text-gray-400 mb-1">Type</p>
                        <p class="font-bold dark:text-gray-200 text-gray-800">
                            {{ ucfirst($note->type) }}
                        </p>
                    </div>
                </div>
            </div>

            <div class="rounded-2xl p-5 dark:bg-[#17141f] bg-white border dark:border-pink-500/[0.18] border-orange-100">
                <h3 class="text-[18px] font-extrabold dark:text-white text-gray-900 mb-4">
                    Tags
                </h3>

                <div class="flex flex-wrap gap-2">
                    @forelse($note->tags as $tag)
                        <span class="px-3 py-1.5 rounded-lg text-[12px] font-semibold
                            dark:bg-[#21192c] bg-orange-50 dark:text-gray-300 text-orange-600">
                            #{{ $tag->name }}
                        </span>
                    @empty
                        <p class="text-[14px] dark:text-gray-500 text-gray-500">No tags added.</p>
                    @endforelse
                </div>
            </div>

            <div class="rounded-2xl p-5 dark:bg-[#17141f] bg-white border dark:border-pink-500/[0.18] border-orange-100 space-y-3">
                <form action="{{ route('user.notes.toggle-pin', $note) }}" method="POST">
                    @csrf
                    <button class="w-full px-4 py-3 rounded-xl text-[14px] font-bold
                        dark:text-white text-gray-800 border dark:border-white/[0.12] border-orange-200
                        dark:bg-white/[0.03] bg-white">
                        {{ $note->is_pinned ? 'Unpin Note' : 'Pin Note' }}
                    </button>
                </form>

                <form action="{{ route('user.notes.toggle-favorite', $note) }}" method="POST">
                    @csrf
                    <button class="w-full px-4 py-3 rounded-xl text-[14px] font-bold text-white
                        bg-gradient-to-r from-orange-500 to-pink-500">
                        {{ $note->is_favorite ? 'Remove Favorite' : 'Add Favorite' }}
                    </button>
                </form>

                <form action="{{ route('user.notes.destroy', $note) }}" method="POST">
                    @csrf
                    @method('DELETE')

                    <button onclick="return confirm('Delete this note?')"
                        class="w-full px-4 py-3 rounded-xl text-[14px] font-bold
                        bg-red-500/10 text-red-500 border border-red-500/20">
                        Delete Note
                    </button>
                </form>
            </div>
        </aside>
    </div>
</div>
@endsection